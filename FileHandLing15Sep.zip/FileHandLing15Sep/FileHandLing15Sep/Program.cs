﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace FileHandLing15Sep
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string deskTop = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            Console.WriteLine(deskTop);
            deskTop = deskTop + "\\abc.txt";
            Console.WriteLine(deskTop);
            try
            {
                File.ReadAllLines(deskTop);
            }
            catch
            {
                File.WriteAllText(deskTop, " ");

            }
            //1---add
            Console.WriteLine("enter text in file");
            string content = Console.ReadLine();
            String[] txt = File.ReadAllLines(deskTop);
            bool flag = true;
            for (int i = 0; i < txt.Length; i++)
            {
                if (txt[i] == content)
                    flag = false;

            }
            if (flag)
                File.AppendAllText(deskTop, "\r\n" + content);
            else
                Console.WriteLine("already present");
            //2--Search 
            String[] txt1 = File.ReadAllLines(deskTop);
            Console.WriteLine("enter text for search");
            string serchValue = Console.ReadLine().ToLower();
            bool ispresent = false;
            for (int i = 0; i < txt1.Length; i++)
            {
                if (txt1[i] == serchValue)
                    ispresent = true;
            }
            if (ispresent)
                Console.WriteLine("serached value is present");

            //3--.list All
            String[] txt2 = File.ReadAllLines(deskTop);
            Console.WriteLine("list of texts");
            foreach (string s in txt2)
            {
                Console.WriteLine(s);
            }
            //4--Flex search
            String[] txt3 = File.ReadAllLines(deskTop);
            Console.WriteLine("enter the text to be search");
            string check = Console.ReadLine().ToLower().Trim();
            bool isContains = false;
            for (int i = 0; i < txt3.Length; i++)
            {
                if (txt[i] == check)
                {
                    isContains = true;
                }

            }
            if (isContains)
                Console.WriteLine($"{check} is persent ");



            Console.ReadLine();


        }
    }
}
